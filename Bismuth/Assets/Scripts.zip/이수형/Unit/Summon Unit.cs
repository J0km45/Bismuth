using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Random = UnityEngine.Random;

public class SummonUnit : MonoBehaviour
{
    public event Action OnOwnedTowersChanged;
    [System.Serializable]
    public class UnitPrefabEntry
    {
        [Tooltip("비워두면 prefab.name을 사용")]
        public string unitName;
        public GameObject prefab;
    }

    [System.Serializable]
    public class SummonedTowerRecord
    {
        public int summonIndex;
        public int Id;
        public string unitName;
        public int tier;
        public UnitData unitData;
        public TowerUnit towerUnit;
        public UnitStat unitStat;

        public PlacementSlot CurrentSlot
        {
            get
            {
                if (towerUnit == null)
                    return null;

                return towerUnit.CurrentSlot;
            }
        }
    }

    [Header("Scene References")]
    [SerializeField] private BoardSystem boardSystem;
    [SerializeField] private SynergyManager synergyManager;
    [SerializeField] private PlayerDataManager playerDataManager;
    [SerializeField] private CellHighlight cellHighlight;
    [SerializeField] private Camera worldCamera;
    [SerializeField] private UnitCatalogManager unitCatalogManager;
    [SerializeField] private CombineManager combineManager;

    [Header("Data")]
    [SerializeField] private List<UnitSO> units = new List<UnitSO>(4);
    public List<UnitSO> Units => units;
    [SerializeField] private SummonChanceSO summonSO;

    [Header("Prefab Table")]
    [SerializeField] private List<GameObject> unitPrefabTable = new List<GameObject>();

    [Header("Owned Towers")]
    [SerializeField] private List<SummonedTowerRecord> ownedTowers = new List<SummonedTowerRecord>();
    public IReadOnlyList<SummonedTowerRecord> OwnedTowers => ownedTowers;

    [SerializeField] private bool summonLog = true;
    [SerializeField] private bool boardLog = true;

    private int summonSequence = 0;

    private void Awake()
    {
        if (boardSystem == null)
            boardSystem = BoardSystem.Instance != null ? BoardSystem.Instance : FindAnyObjectByType<BoardSystem>();

        if (synergyManager == null)
            synergyManager = GetComponent<SynergyManager>();

        if (playerDataManager == null)
            playerDataManager = GetComponent<PlayerDataManager>();

        if (cellHighlight == null)
            cellHighlight = FindAnyObjectByType<CellHighlight>();
        if (worldCamera == null)
            worldCamera = Camera.main;

        if (unitCatalogManager == null)
            unitCatalogManager = GetComponent<UnitCatalogManager>();

        if (combineManager == null)
            combineManager = GetComponent<CombineManager>();
    }

    private void Start()
    {
        CleanupNullOwnedTowers();
    }

    public bool TrySummonAndPlace()
    {
        int tierIndex = GetRandomTierIndex();
        if (tierIndex < 0)
            return false;

        UnitData data = GetRandomUnit(tierIndex);
        if (data == null)
            return false;

        return TrySummonAndPlace(data);
    }

    public bool TrySummonAndPlace(UnitData data)
    {
        DebugTool.Log(
            $"소환 시도",
            DebugType.Summon,
            this
        );
        if (data == null)
        {
            DebugTool.Warnning("소환할 UnitData가 없습니다.", DebugType.Summon, this);
            return false;
        }

        if (boardSystem == null)
        {
            DebugTool.Error("BoardSystem 참조가 없습니다.", DebugType.Board, this);
            return false;
        }

        if (!boardSystem.TryGetFirstEmptySlot(out BoardSystem.SlotData emptySlot))
        {
            DebugTool.Warnning("배치 가능한 빈 슬롯이 없습니다.", DebugType.Board, this);
            return false;
        }

        GameObject prefab = GetUnitPrefab(data);

        if (prefab == null)
        {
            DebugTool.Warnning(
                $"유닛 프리팹을 찾지 못했습니다. unitName={data.UnitName}",
                DebugType.Summon,
                this
            );
            return false;
        }

        if (!boardSystem.PlaceNewTower(prefab, emptySlot, out TowerUnit createdTower))
        {
            DebugTool.Warnning("보드에 유닛 배치에 실패했습니다.", DebugType.Board, this);
            return false;
        }

        PrepareSpawnedTower(createdTower, data);
        DebugTool.Log("PrepareSpawnedTower까지 실행완료", DebugType.Summon, this);

        UnitStat stat = ApplyUnitStat(createdTower.gameObject, data);
        createdTower.stat = stat;

        SetAnimationController(createdTower.gameObject);

        EnsureAutoAttack(createdTower.gameObject);
        DebugTool.Log("EnsureAttack까지 실행완료", DebugType.Summon, this);
        synergyManager?.OnUnitCreated?.Invoke(stat);
        unitCatalogManager.OnSummonUnit?.Invoke(stat);

        PrintStat(stat);
        DebugTool.Log("PrintStat까지 실행완료", DebugType.Summon, this);

        RegisterOwnedTower(data, createdTower, stat);
        OnOwnedTowersChanged?.Invoke();
        combineManager.OnAddUnit?.Invoke(stat.Id);

        DebugTool.Log(
            $"소환 성공 - {data.UnitName} / 티어 {data.Tier} / 슬롯 {emptySlot.slot.name}",
            DebugType.Summon,
            this
        );

        return true;
    }

    public bool RemoveOwnedTower(TowerUnit tower)
    {
        if (tower == null)
            return false;

        int index = ownedTowers.FindIndex(record => record != null && record.towerUnit == tower);
        if (index < 0)
            return false;

        combineManager.OnRemoveUnit?.Invoke(ownedTowers[index].Id);
        ownedTowers.RemoveAt(index);
        return true;
    }

    public List<UnitData> GetOwnedUnitDataSnapshot()
    {
        CleanupNullOwnedTowers();

        List<UnitData> result = new List<UnitData>();

        foreach (SummonedTowerRecord record in ownedTowers)
        {
            if (record == null || record.unitData == null)
                continue;

            result.Add(record.unitData);
        }

        return result;
    }

    private int GetRandomTierIndex()
    {
        if (playerDataManager == null)
        {
            DebugTool.Error("PlayerDataManager 참조가 없습니다.", DebugType.Summon, this);
            return -1;
        }

        SummonChanceData data = GetByEnhancementLevel(playerDataManager.Level);
        if (data == null)
        {
            DebugTool.Warnning(
                $"강화 단계 {playerDataManager.Level} 데이터가 없습니다.",
                DebugType.Data,
                this
            );
            return -1;
        }

        float randomValue = Random.Range(0f, 100f);

        if (randomValue < data.Tier1)
            return 0;

        if (randomValue < data.Tier1 + data.Tier2)
            return 1;

        if (randomValue < data.Tier1 + data.Tier2 + data.Tier3)
            return 2;

        return 3;
    }

    private SummonChanceData GetByEnhancementLevel(int enhancementLevel)
    {
        if (summonSO == null || summonSO.Rows == null)
            return null;

        for (int i = 0; i < summonSO.Rows.Count; i++)
        {
            SummonChanceData row = summonSO.Rows[i];

            if (row == null)
                continue;

            if (row.EnhancementLevel == enhancementLevel)
                return row;
        }

        return null;
    }

    private UnitData GetRandomUnit(int tierIndex)
    {
        if (tierIndex < 0 || tierIndex >= units.Count)
            return null;

        if (units[tierIndex] == null)
            return null;

        List<UnitData> tierUnits = units[tierIndex].Units;

        if (tierUnits == null || tierUnits.Count == 0)
        {
            DebugTool.Warnning($"티어 {tierIndex + 1} 유닛 데이터가 없습니다.", DebugType.Data, this);
            return null;
        }

        int randomIndex = Random.Range(0, tierUnits.Count);
        UnitData selected = tierUnits[randomIndex];

        DebugTool.Log(
            $"랜덤 티어 : {tierIndex + 1} | 랜덤 번호 : [{randomIndex + 1}] | 유닛 이름 : {selected.UnitName}",
            DebugType.Summon,
            this
        );

        return selected;
    }

    private GameObject GetUnitPrefab(UnitData data)
    {
        if (data == null)
        {
            DebugTool.Log("데이터 널", DebugType.Data, this);
            return null;
        }

        if (unitPrefabTable.Count == 0)
        {
            DebugTool.Warnning("프리팹 등록 필요", DebugType.Unit, this);
            return null;
        }

        if (unitPrefabTable.Count < (data.Id - 10001))
        {
            DebugTool.Warnning($"{data.Id} : 해당 프리펩을 찾을 수 없습니다.", DebugType.Unit, this);
            return null;
        }

        GameObject prefab = unitPrefabTable[data.Id - 10001];

        return prefab;
    }

    private void PrepareSpawnedTower(TowerUnit unit, UnitData data)
    {
        if (unit == null)
            return;

        unit.gameObject.name = data.Id.ToString();


        TowerLongPressDragHandler dragHandler = unit.GetComponent<TowerLongPressDragHandler>();


        //if (unit.GetComponent<TowerLongPressDragHandler>() == null)
        //    unit.gameObject.AddComponent<TowerLongPressDragHandler>();

        if (dragHandler == null)
            dragHandler = unit.gameObject.AddComponent<TowerLongPressDragHandler>();

        dragHandler.Initialize(boardSystem, worldCamera, cellHighlight);
    }

    private UnitStat ApplyUnitStat(GameObject unitObject, UnitData unitData)
    {
        UnitStat stat = unitObject.GetComponent<UnitStat>();
        if (stat == null)
        {
            DebugTool.Log("유닛 찾을 수 없음", DebugType.Unit, this);
            stat = unitObject.AddComponent<UnitStat>();
        }

        stat.Id = unitData.Id;
        stat.Tier = unitData.Tier;
        stat.Level = 1;
        stat.Name = unitData.UnitName;
        stat.BaseAttackPower = unitData.AttackPower;
        stat.AttackSpeed = unitData.AttackSpeed;
        stat.CritChance = unitData.CriticalChance;
        stat.Range = unitData.Range;
        stat.AttackArea = unitData.AttackArea;
        stat.attackTypes = unitData.AttackType;
        stat.AttackTargetCount = unitData.AttackTargetCount;
        stat.SynergIDs = unitData.SynergyIDs;
        stat.AttackClips = unitData.AttackClips; // TODO : 제갈도원 코드 수정 후 사용

        // StatHub 부착 + Base 값 주입 (Step 2a)
        // 아직 어떤 소비자도 Hub 를 읽지 않는다. 다음 단계에서 소비자 전환 예정.
        UnitStatHub hub = unitObject.GetComponent<UnitStatHub>()
                        ?? unitObject.AddComponent<UnitStatHub>();
        hub.SetBase(StatType.AttackPower,         unitData.AttackPower);
        hub.SetBase(StatType.AttackSpeed,         unitData.AttackSpeed);
        hub.SetBase(StatType.CritChance,          unitData.CriticalChance);
        hub.SetBase(StatType.CritDamage,          0f);
        hub.SetBase(StatType.Range,               unitData.Range);
        hub.SetBase(StatType.AttackArea,          unitData.AttackArea);
        hub.SetBase(StatType.AttackTargetCount,   unitData.AttackTargetCount);
        hub.SetBase(StatType.BonusDamageVsSlowed, 0f);

        DebugTool.Log("스탯 맵핑 완료", DebugType.Data, this);
        return stat;
    }

    private void SetAnimationController(GameObject unitObject)
    {
        if (unitObject == null)
            return;
        DebugTool.Log("애니메이션 컨트롤러 설정 시도", DebugType.Unit, this);
        AnimationController anim = unitObject.GetComponent<AnimationController>();
        if (anim == null)
        {
            anim = unitObject.AddComponent<AnimationController>();
        }
        anim.Initialize();
    }

    private void RegisterOwnedTower(UnitData data, TowerUnit towerUnit, UnitStat stat)
    {
        CleanupNullOwnedTowers();

        ownedTowers.Add(new SummonedTowerRecord
        {
            summonIndex = ++summonSequence,
            Id = stat.Id,
            unitName = data.UnitName,
            tier = data.Tier,
            unitData = data,
            towerUnit = towerUnit,
            unitStat = stat
        });
    }

    private void CleanupNullOwnedTowers()
    {
        ownedTowers.RemoveAll(record => record == null || record.towerUnit == null);
    }
    private void PrintStat(UnitStat stat)
    {
        if (stat == null)
        {
            DebugTool.Warnning("스탯이 없습니다.", DebugType.Summon, this);
            return;
        }

        DebugTool.Log($"ID : {stat.Id}\n" +
                      $"Tier : {stat.Tier}\n" +
                      $"Name : {stat.Name}\n" +
                      $"AttackPower : {stat.BaseAttackPower}\n" +
                      $"AttackSpeed : {stat.AttackSpeed}\n" +
                      $"CritChance : {stat.CritChance}\n" +
                      $"Range : {stat.Range}\n" +
                      $"AttackArea : {stat.AttackArea}\n" +
                      $"AttackType : {stat.attackTypes}\n" +
                      $"AttackTargetCount : {stat.AttackTargetCount}\n" +
                      $"Synerge1 : {stat.SynergIDs[0]}\n" +
                      $"Synerge2 : {stat.SynergIDs[1]}\n" +
                      $"Synerge3 : {stat.SynergIDs[2]}\n"
            , DebugType.Summon, this);
    }

    private void EnsureAutoAttack(GameObject unitObject)
    {
        if (unitObject == null)
            return;

        UnitAutoAttack autoAttack = unitObject.GetComponent<UnitAutoAttack>();
        if (autoAttack == null)
            autoAttack = unitObject.AddComponent<UnitAutoAttack>();

        autoAttack.RefreshFromCurrentStat();
    }

    public bool TryDespawnTower(TowerUnit tower)
    {
        CleanupNullOwnedTowers();

        if (tower == null)
        {
            DebugTool.Warnning("디스폰할 타워가 없습니다.", DebugType.Summon, this);
            return false;
        }

        if (boardSystem == null)
        {
            DebugTool.Error("BoardSystem 참조가 없습니다.", DebugType.Board, this);
            return false;
        }

        PlacementSlot previousSlot = tower.CurrentSlot;
        BoardSystem.SlotData releasedSlot = null;

        if (previousSlot != null)
        {
            if (!boardSystem.TryReleaseTowerSlot(tower, out releasedSlot))
            {
                DebugTool.Warnning("슬롯 해제에 실패하여 디스폰을 중단합니다.", DebugType.Board, this);
                return false;
            }
        }
        else
        {
            DebugTool.Warnning(
                $"{tower.name}은(는) CurrentSlot이 없어 슬롯 해제 없이 디스폰합니다.",
                DebugType.Board,
                this
            );
        }
        
        synergyManager.OnUnitRemoved?.Invoke(tower.stat);
        bool removed = RemoveOwnedTower(tower);
        if (!removed)
        {
            DebugTool.Warnning(
                $"{tower.name}이 ownedTowers 목록에 없어 목록 제거는 건너뜁니다.",
                DebugType.Summon,
                this
            );
        }
        else
        {
            OnOwnedTowersChanged?.Invoke();
        }
        tower.SetDragVisual(false);
        tower.SetSelectionColliderEnabled(false);
        tower.ClearPlacedSlot();

        string slotName = previousSlot != null ? previousSlot.name : "None";

        DebugTool.Log(
            $"디스폰 성공 - {tower.TowerId} / 슬롯 {slotName}",
            DebugType.Summon,
            this
        );
        

        Destroy(tower.gameObject);
        return true;
    }
}
